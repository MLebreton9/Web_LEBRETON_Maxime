function initialize() {
    /* bSupportsLocal vérifie si l'API est Local Storage est supportée */
    var bSupportsLocal = (('localStorage' in window) && window['localStorage'] !== null);

    /* Affiche un message si l'API n'est pas supportée */
    if (!bSupportsLocal) {
        document.getElementById('infoform').innerHTML = "<p>Désolé, ce navigateur ne supporte pas l’API Web Storage du W3C.</p>";
        return;
    }

    /* On remplit le formulaire avec les données du Local Storage s'il n'est pas vide */
    if (window.localStorage.length != 0) {
        document.getElementById('firstName').value = window.localStorage.getItem('firstName');//Permet de remplire le champs first name
        document.getElementById('lastName').value = window.localStorage.getItem('lastName');//Permet de remplire le champs last name
        document.getElementById('postCode').value = window.localStorage.getItem('postCode');//Permet de remplire le champs poste code
    }  
}

/* Cette fonction est appelée lors de l'utilisation du bouton enregistrer sur la page. Elle a pour rôle d'enregistrer les données du formulaire dans le Local Storage */
function storeLocalContent(fName, lName, pCode) {
    window.localStorage.setItem('firstName', fName);
    window.localStorage.setItem('lastName', lName);
    window.localStorage.setItem('postCode', pCode);
}

/* On efface le contenu du local Storage */
function clearLocalContent(fName, lName, pCode) {
    window.localStorage.clear();
}

window.onload = initialize;//On appelle la fonction intialize lors du chargement de la page.





