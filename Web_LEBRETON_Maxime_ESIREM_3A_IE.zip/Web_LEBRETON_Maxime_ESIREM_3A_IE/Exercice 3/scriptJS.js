function testFonctionnalites() {

    /*
    Permet de tester si la fonctionnaliter de geolocalisation est activer sur le navigateur.
    S'il est pris en charge, on affiche "pris en charge", sinon on affiche "non pris en charge"
    */
    document.querySelector("#geoloc").innerHTML = Modernizr.geolocation ? "pris en charge" : "non pris en charge";
    

    /*
    Permet de tester si la fonctionnaliter du toucher tactile est activer sur le navigateur.
    S'il est pris en charge, on affiche "pris en charge", sinon on affiche "non pris en charge"
    */
    document.querySelector("#touch").innerHTML = Modernizr.touch ? "pris en charge" : "non pris en charge";
    

    /*
    Permet de tester si la fonctionnaliter SVG est activer sur le navigateur.
    S'il est pris en charge, on affiche "pris en charge", sinon on affiche "non pris en charge"
    */
    document.querySelector("#svg").innerHTML = Modernizr.svg ? "pris en charge" : "non pris en charge";
    

    /*
    Permet de tester si la fonctionnaliter Canvas est activer sur le navigateur.
    S'il est pris en charge, on affiche "pris en charge", sinon on affiche "non pris en charge"
    */
    document.querySelector("#canvas").innerHTML = Modernizr.canvas ? "pris en charge" : "non pris en charge";
    


}
window.onload = testFonctionnalites;


